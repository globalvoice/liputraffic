# Liputraffic API

FastAPI middleware to fetch vehicle location by unit number and return the real address using Google Maps API.